import prompt


def welcome_user():
    print('Welcome to the Brain Games\n')
    name = prompt.string('May i have your name? \n')
    print('Hello, {}'.format(name))
